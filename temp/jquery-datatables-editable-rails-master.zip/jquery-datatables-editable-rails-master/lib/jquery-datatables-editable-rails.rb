require "jquery/datatables/editable/rails/version"
require "jquery/datatables/editable/rails/engine"
