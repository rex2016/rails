module Jquery
  module Datatables
    module Editable
      module Rails
        VERSION = "1.3"
      end
    end
  end
end
